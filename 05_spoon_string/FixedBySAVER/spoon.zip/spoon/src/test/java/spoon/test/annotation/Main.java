package spoon.test.annotation;


public class Main {

	public void m(@Bound(max = 8) int a) {
	} 

}
