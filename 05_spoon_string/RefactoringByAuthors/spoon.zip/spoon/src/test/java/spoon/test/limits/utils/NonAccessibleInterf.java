package spoon.test.limits.utils;

interface NonAccessibleInterf {
}
