package spoon.test.fieldaccesses;

public class InternalSuperCall{
	
	public void methode(){
		InternalSuperCall.super.toString();
	}
}

