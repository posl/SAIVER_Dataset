Spoon-code is a library for analyzing and transforming Java source code.

