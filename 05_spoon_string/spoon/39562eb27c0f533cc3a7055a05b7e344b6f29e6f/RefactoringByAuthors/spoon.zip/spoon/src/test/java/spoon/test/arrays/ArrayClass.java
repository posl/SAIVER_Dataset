package spoon.test.arrays;

public class ArrayClass {

	int[][][] i=new int[0][][];
	
	void m() {
		int[][][] i=new int[0][][];
		i[0]=null;
	}
	
	
}
