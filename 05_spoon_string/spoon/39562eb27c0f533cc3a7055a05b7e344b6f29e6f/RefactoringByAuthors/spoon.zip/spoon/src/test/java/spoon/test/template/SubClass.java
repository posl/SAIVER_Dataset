package spoon.test.template;

public class SubClass extends SuperClass {

}
