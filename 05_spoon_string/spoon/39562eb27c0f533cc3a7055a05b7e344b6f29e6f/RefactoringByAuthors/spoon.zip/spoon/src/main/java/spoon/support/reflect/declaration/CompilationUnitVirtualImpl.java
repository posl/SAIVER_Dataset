package spoon.support.reflect.declaration;

import spoon.support.reflect.cu.CompilationUnitImpl;


public class CompilationUnitVirtualImpl extends CompilationUnitImpl  {

	@Override
	public String getOriginalSourceCode() {
		return "";
	}
	
}
