package com.github.davidmoten.rx.jdbc;

import org.junit.Test;

import com.github.davidmoten.junit.Asserts;

public class QueriesTest {

    @Test
    public void obtainCoverageOfPrivateConstructor() {
        Asserts.assertIsUtilityClass(Queries.class);
    }

}
