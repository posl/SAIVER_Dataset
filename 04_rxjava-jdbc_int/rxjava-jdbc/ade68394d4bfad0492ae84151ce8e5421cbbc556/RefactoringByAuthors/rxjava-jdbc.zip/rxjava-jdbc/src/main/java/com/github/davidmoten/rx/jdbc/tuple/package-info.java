/**
 * Tuples used to map ResultSet rows into strongly typed values.
 */
package com.github.davidmoten.rx.jdbc.tuple;